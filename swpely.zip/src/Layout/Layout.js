import React from "react";
import HomePage from "../Pages/HomePage";

const Layout = () => {
  return (
    <>
      <HomePage />
    </>
  );
};

export default Layout;
