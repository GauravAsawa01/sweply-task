import { Badge, Box, Image, SimpleGrid, Text } from "@chakra-ui/react";
import axios from "axios";
import React, { useEffect, useState } from "react";

const Product = () => {
  const [items, setItems] = useState([]);
  const getProduct = async () => {
    const product = await axios.get("https://fakestoreapi.com/products");
    console.log(product.data);
    setItems(product.data);
    console.log(items);
  };

  useEffect(() => {
    getProduct();
  }, []);
  return (
    <Box>
      <Text fontSize="35px" fontWeight="600" mt={3}>
        Best Collections
      </Text>
      <Text fontSize="13px">All / Bags / Dress</Text>
      <SimpleGrid columns={3} spacing={6} mt={3}>
        {items.map((product) => (
          <Box
            maxW="sm"
            borderWidth="1px"
            borderRadius="lg"
            display="flex"
            bg="white"
            height="200px"
            key={product.id}
          >
            <Box>
              <Image
                src={product.image}
                alt={product.description}
                bg="lightgray"
              />
            </Box>
            <Box p="6">
              <Box
                mt="1"
                fontWeight="semibold"
                as="h4"
                lineHeight="tight"
                noOfLines={1}
                display="flex"
              >
                {product.title}
              </Box>

              <Box>
                {product.price}
                <Box as="span" color="gray.600" fontSize="sm">
                  / wk
                </Box>
              </Box>
            </Box>
          </Box>
        ))}
      </SimpleGrid>
    </Box>
  );
};

export default Product;
